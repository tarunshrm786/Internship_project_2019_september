var firebaseConfig = {
    apiKey: "AIzaSyD03fGqw-DuHtd4gTCInilRpRgvEerPUoM",
    authDomain: "fir-connect-bdaab.firebaseapp.com",
    databaseURL: "https://fir-connect-bdaab.firebaseio.com",
    projectId: "fir-connect-bdaab",
    storageBucket: "fir-connect-bdaab.appspot.com",
    messagingSenderId: "647792241875",
    appId: "1:647792241875:web:3c7001eb805a549038b826",
    measurementId: "G-9B864KSCBN"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);


function writeNewPost()
{
    const fb = firebase.database().ref()
    
    password = document.getElementById('pwd').value
//console.log(password);    
    data = {password}
    console.log(data);
    
 fb.child('admin/password').update(data);
}

//
//function writeNewPost(pwd) {
//  // A post entry.
//  var postData = {
//
//       password: pwd, 
// };
//
//  // Get a key for a new Post.
//  var newPostKey = firebase.database().ref().child('admin/password').push().key;
//
//  // Write the new post's data simultaneously in the posts list and the user's post list.
//  var updates = {};
//  updates['/admin/password/' + newPostKey] = postData;
//  //updates['/user-posts/' + uid + '/' + newPostKey] = postData;
//
//  return firebase.database().ref().update(updates);
//}


//var database = firebase.database();
//var adminRef = database.ref().child("admin/");
//
//var result = adminRef.push({
//    
//    Password : snap.child("password").val();;
//});

